@extends('layouts.admin')
@section('content')

<div class="card">
    <div class="card-header">
        {{ trans('cruds.todaysAppointment.title') }}
    </div>

    <div class="card-body">
        <p>
            Text coming soon...
        </p>
    </div>
</div>



@endsection