<?php

return [
    'site_title' => 'Doctor Appoinment',

];
